﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp18
{
    public partial class Form3 : Form
    {
        public Model1 db { get; set; }
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Нужно ввести все требуемые данные!");
                return;
            }
            //Преобразуем данные из textBox1 в целый тип
            int id;
            bool b = int.TryParse(textBox1.Text, out id);
            if (b == false)
            {
                MessageBox.Show("Неверный формат ID - " + textBox1.Text);
                return;
            }
            int cost;
            bool n = int.TryParse(textBox4.Text, out cost);

            //Добавление новой записи в таблицу БД
            //Создаем новый объект для коллекции
            Product pd = new Product();
            //Задаем свойства объекта
            pd.ID = id;
            pd.Title = textBox2.Text;
            pd.Cost = cost;
            pd.Description = textBox4.Text;
            //Добавляем новый объект к коллекции
            db.Product.Add(pd);

            try
            {
                //Сохраняем изменения коллекции в БД
                db.SaveChanges();
                //Задаем свойство DialogResult, чтобы закрыть форму
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            { //Сложная конструкция для показа сообщений сервера БД
              //MessageBox.Show(ex.InnerException.InnerException.Message);
            }
            Update();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
        }
    }
}

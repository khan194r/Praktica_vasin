﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp18
{
    public partial class Form2 : Form
    {
        Model1 db = new Model1();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            productBindingSource.DataSource = db.Product.ToList();
            manufacturerBindingSource.DataSource = db.Manufacturer.ToList();
            productSaleBindingSource.DataSource = db.ProductSale.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();

            frm3.db = db;

            DialogResult dr = frm3.ShowDialog();

            if (dr == DialogResult.OK)
            { //Если данные были добавлены к БД, то обновляем содержание промежуточного объекта
                productBindingSource.DataSource = db.Product.ToList();
                Update();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Product pr = (Product)productBindingSource.Current;
            //Показываем диалоговое окно с кнопками Yes и No
            DialogResult dr = MessageBox.Show("Вы действительно хотите удалить запись в таблице? - " + pr.ID.ToString(), "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //Если пользователь нажал кнопку «Да», то удаляем данные из БД
            if (dr == DialogResult.Yes)
            {
                //Удаление записи из БД
                db.Product.Remove(pr);
                try
                {
                    db.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                productBindingSource.DataSource = db.Product.ToList();

            }
        }
    }
}
